﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Лаборатория.Models;
using Лаборатория.ViewModels;

namespace Лаборатория
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Captcha _captcha;
        public MainWindow()
        {
            InitializeComponent();
            _captcha = new Captcha();
            ShowCaptcha(); // CAPTCHA появляется сразу при запуске
        }
        private void ShowPasswordToggle_Click(object sender, RoutedEventArgs e)
        {
            if (ShowPasswordToggle.IsChecked == true)
            {
                // Показываем TextBox, скрываем PasswordBox
                PasswordTextBox.Text = PasswordBox.Password;
                PasswordTextBox.Visibility = Visibility.Visible;
                PasswordBox.Visibility = Visibility.Collapsed;
            }
            else
            {
                // Показываем PasswordBox, скрываем TextBox
                PasswordBox.Password = PasswordTextBox.Text;
                PasswordBox.Visibility = Visibility.Visible;
                PasswordTextBox.Visibility = Visibility.Collapsed;
            }
        }

        private void ShowCaptcha()
        {
            CaptchaPanel.Visibility = Visibility.Visible;
            UpdateCaptchaImage();
        }

        private void UpdateCaptchaImage()
        {
            CaptchaContainer.Child = _captcha.GenerateCanvas();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var login = LoginTextBox.Text;
            var password = PasswordBox.Password; // Важно: используйте PasswordBox

            Console.WriteLine($"Trying auth: {login}"); // Логирование



            var user = DatabaseHelper.AuthenticateUser(login, password);
            if (user != null)
            {
                // Успешный вход
            }
            else
            {
                MessageBox.Show("Ошибка входа. Проверьте логин и пароль.");
            }
        }

        private void RefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            _captcha.GenerateNew();
            UpdateCaptchaImage();
        }

        private void OpenUserWindow(User user)
        {
            Window userWindow = null;

            switch (user.Role)
            {
                case "Patient":
                    userWindow = new PatientWindow(user);
                    break;
                case "LabWorker":
                    userWindow = new LabWorkerWindow(user);
                    break;
                case "Accountant":
                    userWindow = new AccountantWindow(user);
                    break;
                case "Admin":
                    userWindow = new AdminWindow(user);
                    break;
            }

            if (userWindow != null)
            {
                userWindow.Show();
                this.Close();
            }
        }
    }
}