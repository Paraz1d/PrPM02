﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerServiceApp.Models
{
    public class ServiceRequest
    {
        public int RequestId { get; set; }
        public int ClientId { get; set; }
        public string DeviceType { get; set; }
        public string DeviceModel { get; set; }
        public string ProblemDescription { get; set; }
        public DateTime? CreatedAt { get; set; }
        public int StatusId { get; set; }
        public int? AssignedTechnicianId { get; set; }
        public DateTime? CompletionDate { get; set; }
    }
}
