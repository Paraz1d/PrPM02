﻿using System.ComponentModel;
using Лаборатория.Models;

namespace Лаборатория.ViewModels
{
    public class LabWorkerViewModel : INotifyPropertyChanged
    {
        private readonly User _currentUser;

        public LabWorkerViewModel(User user)
        {
            _currentUser = user;
        }

        public string UserFullName => _currentUser.FullName;
        public string UserRole => "Лаборант";

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
