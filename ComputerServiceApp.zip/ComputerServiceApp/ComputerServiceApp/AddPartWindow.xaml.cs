﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace ComputerServiceApp
{
    public partial class AddPartWindow : Window
    {
        private readonly string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ComputerServiceCompanyDB"].ConnectionString;

        public AddPartWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PartNameTextBox.Text) ||
                !decimal.TryParse(PriceTextBox.Text, out decimal price) ||
                !int.TryParse(QuantityTextBox.Text, out int quantity))
            {
                MessageBox.Show("Пожалуйста, введите корректные название, цену и количество.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string query = @"INSERT INTO Parts (PartName, PartCode, Price, QuantityInStock, Description) 
                             VALUES (@PartName, @PartCode, @Price, @QuantityInStock, @Description)";

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@PartName", PartNameTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@PartCode", string.IsNullOrWhiteSpace(PartCodeTextBox.Text) ? DBNull.Value : (object)PartCodeTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.Parameters.AddWithValue("@QuantityInStock", quantity);
                cmd.Parameters.AddWithValue("@Description", string.IsNullOrWhiteSpace(DescriptionTextBox.Text) ? DBNull.Value : (object)DescriptionTextBox.Text.Trim());

                conn.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Запчасть добавлена успешно.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.DialogResult = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении запчасти: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
