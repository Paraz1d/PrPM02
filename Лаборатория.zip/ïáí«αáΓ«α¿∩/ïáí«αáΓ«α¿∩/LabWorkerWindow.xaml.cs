﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Лаборатория.Models;

namespace Лаборатория.ViewModels
{
    /// <summary>
    /// Логика взаимодействия для LabWorkerWindow.xaml
    /// </summary>
    public partial class LabWorkerWindow : Window
    {
        private readonly User _currentUser;
        private DispatcherTimer _sessionTimer;
        private TimeSpan _sessionTimeLeft;
        private const int SessionDurationMinutes = 10;
        public LabWorkerWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            DataContext = new LabWorkerViewModel(user);
            LoadOrders();
            InitializeSessionTimer();
        }
        private void InitializeSessionTimer()
        {
            _sessionTimeLeft = TimeSpan.FromMinutes(SessionDurationMinutes);
            SessionTimerText.Text = _sessionTimeLeft.ToString(@"mm\:ss");

            _sessionTimer = new DispatcherTimer();
            _sessionTimer.Interval = TimeSpan.FromSeconds(1);
            _sessionTimer.Tick += SessionTimer_Tick;
            _sessionTimer.Start();
        }

        private void SessionTimer_Tick(object sender, EventArgs e)
        {
            _sessionTimeLeft = _sessionTimeLeft.Subtract(TimeSpan.FromSeconds(1));
            SessionTimerText.Text = _sessionTimeLeft.ToString(@"mm\:ss");

            // Предупреждение за 5 минут до конца (для теста - за 1 минуту)
            if (_sessionTimeLeft <= TimeSpan.FromMinutes(1))
            {
                SessionWarningText.Text = "До конца сеанса осталось менее 1 минуты!";
            }

            // Завершение сеанса
            if (_sessionTimeLeft <= TimeSpan.Zero)
            {
                _sessionTimer.Stop();
                MessageBox.Show("Время сеанса истекло. Система будет заблокирована на 1 минуту.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                BlockSystem();
            }
        }

        private void BlockSystem()
        {
            // Блокировка системы на 1 минуту (для теста)
            var timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMinutes(1);
            timer.Tick += (s, e) => { timer.Stop(); };
            timer.Start();

            // Закрытие текущего окна
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void LoadOrders()
        {
            string query = @"
                SELECT з.ID_заказа, п.ФИО AS Пациент, з.ДатаСоздания, з.СтатусЗаказа
                FROM Заказы з
                JOIN Пациенты п ON з.ID_пациента = п.ID_пациента
                WHERE з.Архивный = 0 AND з.СтатусЗаказа = 'Создан'
                ORDER BY з.ДатаСоздания DESC";

            using (SqlConnection connection = DatabaseHelper.GetConnection())
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                try
                {
                    connection.Open();
                    adapter.Fill(table);
                    OrdersGrid.ItemsSource = table.DefaultView;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CreateNewOrder_Click(object sender, RoutedEventArgs e)
        {
            // Реализация создания нового заказа
            MessageBox.Show("Функция создания нового заказа будет реализована позже", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RefreshOrders_Click(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        private void ViewOrder_Click(object sender, RoutedEventArgs e)
        {
            // Реализация просмотра заказа
            MessageBox.Show("Функция просмотра заказа будет реализована позже", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            _sessionTimer.Stop();
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}