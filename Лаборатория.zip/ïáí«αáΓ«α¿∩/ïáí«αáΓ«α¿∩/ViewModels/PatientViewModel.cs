﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{
    public class PatientViewModel : INotifyPropertyChanged
    {
        private readonly User _currentUser;

        public PatientViewModel(User user)
        {
            _currentUser = user;
        }

        public string UserFullName => _currentUser.FullName;
        public string UserRole => "Пациент";

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
