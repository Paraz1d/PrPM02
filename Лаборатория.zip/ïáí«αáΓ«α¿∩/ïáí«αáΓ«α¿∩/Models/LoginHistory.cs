﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{
    public class LoginHistory
    {
        public int Id { get; set; }
        public string UserLogin { get; set; }
        public DateTime AttemptTime { get; set; }
        public bool IsSuccessful { get; set; }
        public string IpAddress { get; set; }
        public string UserAgent { get; set; }
        public string Role { get; set; }
    }
}
