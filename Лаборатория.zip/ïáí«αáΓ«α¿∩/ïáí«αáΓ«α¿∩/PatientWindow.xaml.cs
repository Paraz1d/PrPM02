﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Лаборатория.Models;

namespace Лаборатория
{
    /// <summary>
    /// Логика взаимодействия для PatientWindow.xaml
    /// </summary>
    public partial class PatientWindow : Window
    {
        private readonly User _currentUser;
        public PatientWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            DataContext = new PatientViewModel(user);
            LoadPatientData();
        }
        private void LoadPatientData()
        {
            // Загрузка заказов пациента
            string ordersQuery = @"
                SELECT з.ID_заказа, з.ДатаСоздания, з.СтатусЗаказа, 
                       COUNT(зу.ID_услуги) AS КоличествоУслуг,
                       SUM(у.Стоимость) AS ОбщаяСтоимость
                FROM Заказы з
                JOIN ЗаказыУслуги зу ON з.ID_заказа = зу.ID_заказа
                JOIN Услуги у ON зу.ID_услуги = у.ID_услуги
                WHERE з.ID_пациента = @PatientId AND з.Архивный = 0
                GROUP BY з.ID_заказа, з.ДатаСоздания, з.СтатусЗаказа
                ORDER BY з.ДатаСоздания DESC";

            using (SqlConnection connection = DatabaseHelper.GetConnection())
            {
                SqlCommand command = new SqlCommand(ordersQuery, connection);
                command.Parameters.AddWithValue("@PatientId", _currentUser.Id);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable ordersTable = new DataTable();

                try
                {
                    connection.Open();
                    adapter.Fill(ordersTable);
                    OrdersGrid.ItemsSource = ordersTable.DefaultView;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            // Загрузка результатов анализов
            string resultsQuery = @"
                SELECT у.Наименование, оу.ДатаВремяВыполнения, оу.Результат
                FROM ОказанныеУслуги оу
                JOIN ЗаказыУслуги зу ON оу.ID_заказа_услуги = зу.ID_заказа_услуги
                JOIN Услуги у ON зу.ID_услуги = у.ID_услуги
                JOIN Заказы з ON зу.ID_заказа = з.ID_заказа
                WHERE з.ID_пациента = @PatientId
                ORDER BY оу.ДатаВремяВыполнения DESC";

            using (SqlConnection connection = DatabaseHelper.GetConnection())
            {
                SqlCommand command = new SqlCommand(resultsQuery, connection);
                command.Parameters.AddWithValue("@PatientId", _currentUser.Id);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable resultsTable = new DataTable();

                try
                {
                    connection.Open();
                    adapter.Fill(resultsTable);
                    ResultsGrid.ItemsSource = resultsTable.DefaultView;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Ошибка загрузки результатов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}