﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Лаборатория.Models;

namespace Лаборатория
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            try
            {
                // Проверка подключения к БД
                using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LaboratoryDB"].ConnectionString))
                {
                    connection.Open();
                    connection.Close();
                }

                base.OnStartup(e);
                new MainWindow().Show();
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных:\n{ex.Message}",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
                Shutdown();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Критическая ошибка:\n{ex.Message}",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
                Shutdown();
            }
            if (!DatabaseExists())
            {
                CreateDatabase();
            }
        }
        private bool DatabaseExists()
        {
            string masterConn = "Data Source=.;Integrated Security=True;Initial Catalog=master";
            using (var connection = new SqlConnection(masterConn))
            {
                var cmd = new SqlCommand(
                    "SELECT 1 FROM sys.databases WHERE name = 'Лаборатория'",
                    connection);
                try
                {
                    connection.Open();
                    return cmd.ExecuteScalar() != null;
                }
                catch { return false; }
            }
        }

        private void CreateDatabase()
        {
            string masterConn = "Data Source=.;Integrated Security=True;Initial Catalog=master";
            using (var connection = new SqlConnection(masterConn))
            {
                var cmd = new SqlCommand(
                    "CREATE DATABASE [Лаборатория]",
                    connection);
                try
                {
                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не удалось создать базу данных: {ex.Message}");
                }
            }
        }

    }
}
