﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace Лаборатория.Models
{
    public class Captcha
    {
        private string _text;
        private readonly Random _random = new Random();

        public string Text => _text;

        public Captcha()
        {
            GenerateNew();
        }

        public void GenerateNew()
        {
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
            char[] captchaText = new char[4];

            for (int i = 0; i < 4; i++)
            {
                captchaText[i] = chars[_random.Next(chars.Length)];
            }

            _text = new string(captchaText);
        }

        public Canvas GenerateCanvas()
        {
            var canvas = new Canvas
            {
                Width = 150,
                Height = 50,
                Background = Brushes.White
            };

            // Добавляем текст
            for (int i = 0; i < _text.Length; i++)
            {
                var textBlock = new TextBlock
                {
                    Text = _text[i].ToString(),
                    FontSize = _random.Next(18, 24),
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.Black,
                    RenderTransform = new RotateTransform(_random.Next(-15, 15))
                };

                Canvas.SetLeft(textBlock, 10 + i * 30 + _random.Next(-5, 5));
                Canvas.SetTop(textBlock, 10 + _random.Next(-5, 5));
                canvas.Children.Add(textBlock);
            }

            // Добавляем шум - линии
            for (int i = 0; i < 3; i++)
            {
                var line = new Line
                {
                    X1 = _random.Next(0, 50),
                    Y1 = _random.Next(0, 50),
                    X2 = _random.Next(100, 150),
                    Y2 = _random.Next(0, 50),
                    Stroke = Brushes.Gray,
                    StrokeThickness = 1
                };
                canvas.Children.Add(line);
            }

            // Добавляем шум - точки
            for (int i = 0; i < 20; i++)
            {
                var ellipse = new Ellipse
                {
                    Width = _random.Next(1, 3),
                    Height = _random.Next(1, 3),
                    Fill = Brushes.Gray
                };

                Canvas.SetLeft(ellipse, _random.Next(0, 150));
                Canvas.SetTop(ellipse, _random.Next(0, 50));
                canvas.Children.Add(ellipse);
            }

            return canvas;
        }
    }
}
