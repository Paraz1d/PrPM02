﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using ComputerServiceApp.Models;
using System.Configuration;

namespace ComputerServiceApp
{
    public partial class MainAppWindow : Window
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["ComputerServiceCompanyDB"].ConnectionString;

        public MainAppWindow()
        {
            InitializeComponent();
            LoadClients();
            LoadParts();
            LoadRequests();
        }

        private void LoadClients()
        {
            var clients = new List<Client>();

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("SELECT * FROM Clients", conn))
            {
                conn.Open();
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    clients.Add(new Client
                    {
                        ClientId = (int)reader["ClientId"],
                        FullName = reader["FullName"].ToString(),
                        Phone = reader["Phone"].ToString(),
                        Email = reader["Email"] as string,
                        Address = reader["Address"] as string,
                        RegistrationDate = reader["RegistrationDate"] as System.DateTime?
                    });
                }
            }

            ClientsDataGrid.ItemsSource = clients;
        }

        private void LoadParts()
        {
            var parts = new List<Part>();

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("SELECT * FROM Parts", conn))
            {
                conn.Open();
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    parts.Add(new Part
                    {
                        PartId = (int)reader["PartId"],
                        PartName = reader["PartName"].ToString(),
                        PartCode = reader["PartCode"] as string,
                        Price = (decimal)reader["Price"],
                        QuantityInStock = (int)reader["QuantityInStock"],
                        Description = reader["Description"] as string
                    });
                }
            }

            PartsDataGrid.ItemsSource = parts;
        }

        private void LoadRequests()
        {
            var requests = new List<ServiceRequest>();

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("SELECT * FROM ServiceRequests", conn))
            {
                conn.Open();
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    requests.Add(new ServiceRequest
                    {
                        RequestId = (int)reader["RequestId"],
                        ClientId = (int)reader["ClientId"],
                        DeviceType = reader["DeviceType"].ToString(),
                        DeviceModel = reader["DeviceModel"] as string,
                        ProblemDescription = reader["ProblemDescription"].ToString(),
                        CreatedAt = reader["CreatedAt"] as System.DateTime?,
                        StatusId = (int)reader["StatusId"],
                        AssignedTechnicianId = reader["AssignedTechnicianId"] as int?,
                        CompletionDate = reader["CompletionDate"] as System.DateTime?
                    });
                }
            }

            RequestsDataGrid.ItemsSource = requests;
        }

        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddClientWindow { Owner = this };
            if (window.ShowDialog() == true)
            {
                LoadClients();
            }
        }

        private void AddPart_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddPartWindow { Owner = this };
            if (window.ShowDialog() == true)
            {
                LoadParts();
            }
        }

        private void AddRequest_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddRequestWindow { Owner = this };
            if (window.ShowDialog() == true)
            {
                LoadRequests();
            }
        }
    }
}
