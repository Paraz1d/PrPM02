﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace Лаборатория.Models
{
    public static class DatabaseHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["LaboratoryDB"].ConnectionString;

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public static User AuthenticateUser(string login, string password)
        {
            User user = null;
            Console.WriteLine($"Auth attempt: {login}");

            try
            {
                string query = @"
            SELECT 'Patient' AS Role, ID_пациента AS Id, ФИО AS FullName, NULL AS LastLogin 
            FROM Пациенты WHERE Логин = @Login AND Пароль = @Password AND Архивный = 0
            UNION
            SELECT 'LabWorker' AS Role, ID_лаборанта AS Id, ФИО AS FullName, ПоследняяДатаВхода AS LastLogin 
            FROM Лаборанты WHERE Логин = @Login AND Пароль = @Password AND Архивный = 0
            UNION
            SELECT 'Accountant' AS Role, ID_бухгалтера AS Id, ФИО AS FullName, ПоследняяДатаВхода AS LastLogin 
            FROM Бухгалтеры WHERE Логин = @Login AND Пароль = @Password AND Архивный = 0
            UNION
            SELECT 'Admin' AS Role, ID_администратора AS Id, Логин AS FullName, ПоследняяДатаВхода AS LastLogin 
            FROM Администраторы WHERE Логин = @Login AND Пароль = @Password AND Архивный = 0";

                using (var connection = GetConnection())
                {
                    var cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@Password", password);

                    connection.Open();
                    var reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        user = new User
                        {
                            Role = reader["Role"].ToString(),
                            Id = Convert.ToInt32(reader["Id"]),
                            FullName = reader["FullName"].ToString(),
                            LastLogin = reader["LastLogin"] != DBNull.Value
                                ? Convert.ToDateTime(reader["LastLogin"])
                                : (DateTime?)null
                        };

                        Console.WriteLine($"User found: {user.Role}");
                        UpdateLastLogin(user.Role, user.Id);
                        LogLoginAttempt(login, true);
                    }
                    else
                    {
                        Console.WriteLine("No user found");
                        LogLoginAttempt(login, false);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Auth error: {ex.Message}");
            }

            return user;
        }

        private static void UpdateLastLogin(string role, int id)
        {
            string tableName = "";
            string idColumn = "";

            switch (role)
            {
                case "Patient":
                    tableName = "Пациенты";
                    idColumn = "ID_пациента";
                    break;
                case "LabWorker":
                    tableName = "Лаборанты";
                    idColumn = "ID_лаборанта";
                    break;
                case "Accountant":
                    tableName = "Бухгалтеры";
                    idColumn = "ID_бухгалтера";
                    break;
                case "Admin":
                    tableName = "Администраторы";
                    idColumn = "ID_администратора";
                    break;
            }

            string query = $"UPDATE {tableName} SET ПоследняяДатаВхода = GETDATE() WHERE {idColumn} = @Id";

            using (SqlConnection connection = GetConnection())
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        private static void LogLoginAttempt(string login, bool isSuccessful)
        {
            string query = "INSERT INTO ИсторияВхода (ЛогинПользователя, Успешная) VALUES (@Login, @IsSuccessful)";

            using (SqlConnection connection = GetConnection())
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", login);
                command.Parameters.AddWithValue("@IsSuccessful", isSuccessful);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

    }
}