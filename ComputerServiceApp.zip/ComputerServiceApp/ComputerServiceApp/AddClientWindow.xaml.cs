﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Collections.Generic;
using System.Data;
using System.Windows.Controls;
using ComputerServiceApp.Models;
using System.Configuration;
namespace ComputerServiceApp
{
    public partial class AddClientWindow : Window
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["ComputerServiceCompanyDB"].ConnectionString;

        public AddClientWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text) || string.IsNullOrWhiteSpace(PhoneTextBox.Text))
            {
                MessageBox.Show("Введите ФИО и телефон.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string query = "INSERT INTO Clients (FullName, Phone, Email, Address, Notes, RegistrationDate) " +
                           "VALUES (@FullName, @Phone, @Email, @Address, @Notes, @RegistrationDate)";

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@FullName", FullNameTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Phone", PhoneTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", EmailTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Address", AddressTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@Notes", NotesTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@RegistrationDate", DateTime.Now);

                conn.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Клиент добавлен успешно.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.DialogResult = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении клиента: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
