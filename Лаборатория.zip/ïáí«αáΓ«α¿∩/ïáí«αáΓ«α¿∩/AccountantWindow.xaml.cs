﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Лаборатория.Models;
using Лаборатория.ViewModels;

namespace Лаборатория
{
    /// <summary>
    /// Логика взаимодействия для AccountantWindow.xaml
    /// </summary>
    public partial class AccountantWindow : Window
    {
        private readonly User _currentUser;
        public AccountantWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            DataContext = new AccountantViewModel(user);

            // Установка дат по умолчанию
            StartDatePicker.SelectedDate = DateTime.Today.AddMonths(-1);
            EndDatePicker.SelectedDate = DateTime.Today;
        }
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (StartDatePicker.SelectedDate == null || EndDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите период для формирования отчета", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string query = @"
                SELECT 
                    CONVERT(DATE, оу.ДатаВремяВыполнения) AS Дата,
                    у.Наименование AS Услуга,
                    COUNT(*) AS Количество,
                    SUM(у.Стоимость) AS Сумма
                FROM ОказанныеУслуги оу
                JOIN ЗаказыУслуги зу ON оу.ID_заказа_услуги = зу.ID_заказа_услуги
                JOIN Услуги у ON зу.ID_услуги = у.ID_услуги
                WHERE оу.ДатаВремяВыполнения BETWEEN @StartDate AND @EndDate
                GROUP BY CONVERT(DATE, оу.ДатаВремяВыполнения), у.Наименование
                ORDER BY CONVERT(DATE, оу.ДатаВремяВыполнения) DESC, у.Наименование";

            using (SqlConnection connection = DatabaseHelper.GetConnection())
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StartDate", StartDatePicker.SelectedDate.Value);
                command.Parameters.AddWithValue("@EndDate", EndDatePicker.SelectedDate.Value.AddDays(1));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();

                try
                {
                    connection.Open();
                    adapter.Fill(table);
                    ReportGrid.ItemsSource = table.DefaultView;
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Ошибка формирования отчета: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Функция экспорта в Excel будет реализована позже", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}