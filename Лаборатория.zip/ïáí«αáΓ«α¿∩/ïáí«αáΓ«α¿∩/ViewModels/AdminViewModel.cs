﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{

    public class AdminViewModel : INotifyPropertyChanged
    {
        private User _currentUser;
        public AdminViewModel(User user)
        {
            _currentUser = user;
        }

        public string UserFullName => _currentUser.FullName;
        public string UserRole => "Администратор";

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
