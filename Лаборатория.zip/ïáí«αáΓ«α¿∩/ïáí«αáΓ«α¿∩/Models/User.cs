﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{
    public class User
    {
        public string Role { get; set; } // Добавляем свойство Role
        public int Id { get; set; }
        public string FullName { get; set; }
        public DateTime? LastLogin { get; set; }
    }
}
