﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Description;

namespace Лаборатория.Models
{
    public class LabTechnician : User
    {
        public List<Service> AvailableServices { get; set; } = new List<Service>();
    }
}
