﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using ComputerServiceApp.Models;
using System.Configuration;

namespace ComputerServiceApp
{
    public partial class AddRequestWindow : Window
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["ComputerServiceCompanyDB"].ConnectionString;

        public AddRequestWindow()
        {
            InitializeComponent();
            LoadClients();
        }

        private void LoadClients()
        {
            var clients = new List<Client>();

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand("SELECT ClientId, FullName FROM Clients", conn))
            {
                conn.Open();
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    clients.Add(new Client
                    {
                        ClientId = (int)reader["ClientId"],
                        FullName = reader["FullName"].ToString()
                    });
                }
            }

            ClientComboBox.ItemsSource = clients;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientComboBox.SelectedValue == null ||
                string.IsNullOrWhiteSpace(DeviceTypeTextBox.Text) ||
                string.IsNullOrWhiteSpace(ProblemDescriptionTextBox.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var clientId = (int)ClientComboBox.SelectedValue;

            string query = @"INSERT INTO ServiceRequests (ClientId, DeviceType, DeviceModel, ProblemDescription, CreatedAt, StatusId) 
                             VALUES (@ClientId, @DeviceType, @DeviceModel, @ProblemDescription, @CreatedAt, @StatusId)";

            using (var conn = new SqlConnection(connectionString))
            using (var cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@ClientId", clientId);
                cmd.Parameters.AddWithValue("@DeviceType", DeviceTypeTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@DeviceModel", string.IsNullOrWhiteSpace(DeviceModelTextBox.Text) ? DBNull.Value : (object)DeviceModelTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@ProblemDescription", ProblemDescriptionTextBox.Text.Trim());
                cmd.Parameters.AddWithValue("@CreatedAt", DateTime.Now);
                cmd.Parameters.AddWithValue("@StatusId", 1); // например, статус "Создан"

                conn.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Заявка добавлена успешно.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.DialogResult = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении заявки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
