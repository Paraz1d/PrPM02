﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerServiceApp.Models
{
    public class Part
    {
        public int PartId { get; set; }
        public string PartName { get; set; }
        public string PartCode { get; set; }
        public decimal Price { get; set; }
        public int QuantityInStock { get; set; }
        public string Description { get; set; }
    }
}
