﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;

namespace ComputerServiceApp
{
    public partial class MainWindow : Window
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["ComputerServiceCompanyDB"].ConnectionString;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ErrorMessage.Text = "Введите логин и пароль.";
                return;
            }

            if (AuthenticateUser(login, password))
            {
                // Авторизация успешна, открываем главное окно
                var mainAppWindow = new MainAppWindow();
                mainAppWindow.Show();
                this.Close();
            }
            else
            {
                ErrorMessage.Text = "Неверный логин или пароль.";
            }
        }

        private bool AuthenticateUser(string username, string password)
        {
            // Пока пароль передаем в открытом виде - для полноты замены реализуйте хеширование!
            bool isAuthenticated = false;

            string query = "SELECT COUNT(1) FROM Users WHERE Username = @Username AND Password = @Password AND IsActive = 1";

            try
            {
                using (var connection = new SqlConnection(connectionString))
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    connection.Open();

                    int count = (int)command.ExecuteScalar();
                    isAuthenticated = count > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            return isAuthenticated;
        }
    }
}
