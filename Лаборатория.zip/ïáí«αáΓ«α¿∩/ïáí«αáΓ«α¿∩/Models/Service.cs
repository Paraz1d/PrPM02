﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{
    public class Service
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public decimal Cost { get; set; }
        public int ExecutionTime { get; set; } // в днях
        public int? AverageDeviation { get; set; } // в днях
        public bool IsArchived { get; set; }
        public DateTime? ArchiveDate { get; set; }
    }
}
