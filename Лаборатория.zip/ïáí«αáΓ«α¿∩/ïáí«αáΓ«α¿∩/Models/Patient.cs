﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{
    public class Patient : User
    {
        public DateTime BirthDate { get; set; }
        public string PassportSeries { get; set; }
        public string PassportNumber { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string InsurancePolicyNumber { get; set; }
        public int InsurancePolicyTypeId { get; set; }
        public int InsuranceCompanyId { get; set; }
    }
}
