﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаборатория.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public DateTime CreationDate { get; set; }
        public string Status { get; set; }
        public int? ExecutionTime { get; set; } // в днях
        public bool IsArchived { get; set; }
        public DateTime? ArchiveDate { get; set; }
        public List<OrderService> Services { get; set; } = new List<OrderService>();
    }
}
